package ref;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.*;

import ref.orgin.Doc;

public class Print extends JDialog {
	int message=10; 
    JLabel lable;
    public Print(String inStr){
        super();
        lable = new JLabel("Printing  "+inStr+",  Please Wait");
        lable.setFont(new Font("����",20,25));
        lable.setForeground(Color.red);
        setLayout(new FlowLayout());
        add(lable);
        
    }
	void print(Doc doc)
	{
		doc.print();
	}

}
