package ref;

import javax.swing.*;

import ref.orgin.Doc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent; 
import java.awt.event.KeyEvent;
import java.io.File;
public class WinTest{
    public static void main(String args[]){
        FirstWindow win=new FirstWindow("�๦�ܴ�ӡ����");
    }
}
class FirstWindow extends JFrame implements ActionListener{
    JMenuBar menubar;
    JMenu menu;
    JMenuItem item1,item2; 
    String fileName[];
    FirstWindow(String s){
       setTitle(s);        
       setSize(600,600);
       setLocation(220,120);
       setVisible(true);   
       File file = new File("ref/Type");
       System.out.println(file.getAbsolutePath());
		FileAccept acceptCondition=new FileAccept("class");
       fileName=file.list(acceptCondition);
		//Print print = new Print();
       menubar=new JMenuBar(); 
       menu=new JMenu("�ļ�");  
       for(int i=0;i<fileName.length;i++)
		{
			String strCurName = fileName[i];
			int ipos = strCurName.lastIndexOf('.');
			String strName = strCurName.substring(0,ipos);
			JMenuItem tempMenu = new JMenuItem("Print "+strName);
			tempMenu.addActionListener(this);
			menu.add(tempMenu);
		    menu.addSeparator();
		}
       //item1=new JMenuItem("��");
       //item2=new JMenuItem("����");
     //  item1.setAccelerator(KeyStroke.getKeyStroke('O')); 
      // item2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,InputEvent.CTRL_MASK));         
       
       //menu.add(item2);
       menubar.add(menu);
       setJMenuBar(menubar);
       validate();
       setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    } 
    public void actionPerformed(ActionEvent e){
    	JMenuItem cur = (JMenuItem)e.getSource();
    	for(int i=0;i<fileName.length;i++)
    	{
    		String strCurName = fileName[i];
			int ipos = strCurName.lastIndexOf('.');
			String strName = strCurName.substring(0,ipos);
			
			if(cur.getLabel().equals("Print "+strName))
			{
				//Print dialog = new Print();
				//dialog.setSize(100,200);
				//dialog.setTitle("print "+strName);
				Doc doc;
				try {
					doc = (Doc)Class.forName("ref.Type."+strName).newInstance();
					doc.print();
				} catch (InstantiationException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IllegalAccessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				//dialog.show();
			}
    	}
    	
     }
}

