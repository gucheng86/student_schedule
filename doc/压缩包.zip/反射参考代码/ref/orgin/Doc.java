package ref.orgin;

 public interface Doc {
	  String strType="Windwos";	 
	  void   print();
}
