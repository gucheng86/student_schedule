package ref.orgin;

public interface File {
       void Read();
       void Close();
}
