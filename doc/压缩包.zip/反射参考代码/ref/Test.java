package ref;
import java.io.*;

import ref.Type.Word;
import ref.orgin.Doc;
class FileAccept implements FilenameFilter{
    String str=null;
    FileAccept(String s){
       str="."+s;
    }
    public boolean accept(File dir,String name){
       return name.endsWith(str);
    }
}
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Word word = new Word();
		File file = new File("../type/class");
		FileAccept acceptCondition=new FileAccept("class");
        String fileName[]=file.list(acceptCondition);
		Print print = new Print("");
		//print.print(word);
		
		try {
			for(int i=0;i<fileName.length;i++)
			{
				String strCurName = fileName[i];
				int ipos = strCurName.lastIndexOf('.');
				String strName = strCurName.substring(0,ipos);
				Doc doc =(Doc)Class.forName("ref."+strName).newInstance();
				print.print(doc);
			}
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
