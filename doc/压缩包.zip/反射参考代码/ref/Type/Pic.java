package ref.Type;

import ref.Print;
import ref.orgin.Doc;

public class Pic implements Doc{
	public void print()
	{
		Print dialog = new Print("Pic");
		dialog.setSize(400,400);
		//dialog.setTitle("print "+strName);
		dialog.show();
		dialog.setLocation(350, 350);
		System.out.println("I am Pic");
	}

}
