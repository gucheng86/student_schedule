package ref.Type;

import ref.Print;
import ref.orgin.Doc;


public class Word implements Doc{
	public void print()
	{
		Print dialog = new Print("Word");
		dialog.setSize(400,400);
		//dialog.setTitle("print "+strName);
		dialog.show();
		dialog.setLocation(350, 350);
		System.out.println(" i am Word");
	}

}
