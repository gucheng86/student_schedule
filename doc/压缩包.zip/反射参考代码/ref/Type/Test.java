package ref.Type;
import ref.orgin.*;
public class Test implements File{
     public void Read()
     {}
     public void Close(){}
}
