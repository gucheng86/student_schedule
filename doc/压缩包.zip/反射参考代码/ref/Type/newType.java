package ref.Type;

import ref.Print;
import ref.orgin.Doc;

public class newType implements Doc{
	public void print()
	{
		Print dialog = new Print("newType");
		
		dialog.setSize(400,400);
		dialog.setLocation(350, 350);
		//dialog.setTitle("print "+strName);
		dialog.show();
		System.out.println("I am newType");
	}
}
